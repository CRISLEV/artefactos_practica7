from setuptools import setup, find_packages

setup(
    name='practica5_repartidor',
    description='Practica 5 de software avanzado',
    version='1.2.0',
    author='Christian Levi Gonzalez Rodriguez',
    author_email='clevi.gonzalez@gmail.com',
    url='https://github.com/CRISLEV/practica4sa',
    packages=find_packages()
)